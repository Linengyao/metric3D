from .ViT_DINO import vit_large
from .ViT_DINO_reg import vit_small_reg, vit_large_reg, vit_giant2_reg 

__all__ = [
    "vit_small_reg",
    "vit_large_reg", 
    "vit_giant2_reg",
]
